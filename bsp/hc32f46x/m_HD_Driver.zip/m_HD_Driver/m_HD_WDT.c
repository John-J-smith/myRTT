/*
*****************************************************************************
 Copyright (C)
 Module         : UART��ز���
 File Name      : m_HD_UART.c
 Description    :
 others         :
 Meter Type     ��
 ----------------------------------------------------------------------------
 Modification History:
 <No.> <version >  <time>        <author>     <contents>

******************************************************************************
*/
#define   __M_HD_WDT_C__

/****************************************************************************/
/* ����ͷ�ļ� */

#ifndef   Debug_M_HD_WDT_err
#define   Debug_M_HD_WDT_err(n)
#endif

#include "m_HD_WDT.h"
/*****************************************************************************
 * prototypes define  *
 ****************************************************************************/

/*****************************************************************************
        TYPE AND CONSTANT
*****************************************************************************/


/********************************************************************************
Function name:
Description:   Wdt period is 3S
                period : CountCycle / (plck3 / div) S   example 16384 / (42000000 / 8192) = 3S
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_Wdt_Config(void)
{
    stc_wdt_init_t stcWdtInit;

    /* configure structure initialization */
    MEM_ZERO_STRUCT(stcWdtInit);

    stcWdtInit.enClkDiv = WdtPclk3Div8192;               /* setting wdt cnt clk : 42000000 / 8192 = 5126 */
    stcWdtInit.enCountCycle = WdtCountCycle16384;        /* cnt period */
    stcWdtInit.enRefreshRange = WdtRefresh0To100Pct;     /* Permit feed dog area */
    stcWdtInit.enSleepModeCountEn = Disable;             /* Sleep Wdt is not cnt */
    stcWdtInit.enRequsetType = WdtTriggerResetRequest;   /* Wdt reset request */
    WDT_Init(&stcWdtInit);
}


