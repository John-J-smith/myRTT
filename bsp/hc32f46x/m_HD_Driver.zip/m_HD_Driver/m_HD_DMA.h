/*
*****************************************************************************
 Copyright (C)
 Module         : DMAģ��
 File Name      : m_HD_DMA.h
 Description    :
 others         :
 Meter Type     ��
 ----------------------------------------------------------------------------
 Modification History:
 <No.> <version >  <time>        <author>     <contents>

*****************************************************************************
*/
#ifndef  __M_HD_DMA_H__
#define  __M_HD_DMA_H__

#include "m_MacroTypedef.h"
/*---------------------------------------------------------------------------*
 * TYPE AND CONSTANT                            *
 *---------------------------------------------------------------------------*/

typedef struct
{
    U8 ucSelfCheckRegister;
    U8 ucSpiReadType;
}ST_SPI_DATA;

typedef enum
{
    SPI_READ_INSTANCE_DATA,
    SPI_READ_OTHER_REGISTER,
}ENUM_SPI_READ_TYPE;
#ifndef __M_HD_DMA_C__
    #define __VAR_DEFINE  extern
#else
    #define __VAR_DEFINE
#endif
    __VAR_DEFINE U8 g_pucSPISnd[BUFFER_SIZE];
    __VAR_DEFINE U8 g_pucSPIRec[BUFFER_SIZE];


    __VAR_DEFINE U8 g_pucSPISlaveSnd[1000];
    __VAR_DEFINE U8 g_pucSPISlaveRec[1000];
    __VAR_DEFINE ST_SPI_DATA          gstSpiData;
#undef __VAR_DEFINE

/*---------------------------------------------------------------------------*
 * prototypes define                            *
 *---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 * external variables                           *
 *---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 * external routine prototypes                  *
 *---------------------------------------------------------------------------*/
extern void m_HD_DMA_Init(void);
extern void m_HD_DMA_DeInit(void);
extern void m_HD_DMA2_Init(void);
extern void m_HD_DMA2_SPISt(U8 ucEnable);

#endif

/*---------------------------------------------------------------------------*/
