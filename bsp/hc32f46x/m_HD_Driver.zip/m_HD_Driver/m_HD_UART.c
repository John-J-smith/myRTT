/*
*****************************************************************************
 Copyright (C)
 Module         : UART��ز���
 File Name      : m_HD_UART.c
 Description    :
 others         :
 Meter Type     ��
 ----------------------------------------------------------------------------
 Modification History:
 <No.> <version >  <time>        <author>     <contents>

******************************************************************************
*/
#define   __M_HD_UART_C__

/****************************************************************************/
/* ����ͷ�ļ� */

#ifndef   Debug_M_HD_UART_err
#define   Debug_M_HD_UART_err(n)
#endif

#include "m_HD_UART.h"

/*****************************************************************************
 * prototypes define  *
 ****************************************************************************/
/*****************************************************************************
        TYPE AND CONSTANT
*****************************************************************************/
static void UsartRxIrqCallback(void);
static void UsartTxCmpltIrqCallback(void);

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
static void UsartRxIrqCallback(void)
{
    if(USART_GetStatus(M4_USART1, UsartRxNoEmpty) == Set)//�Զ�����
    {
        if(s_pstComCtrl[E_PORT_CALIB].usRxBufPt >= COM_MAX_BUF)
        {
            s_pstComCtrl[E_PORT_CALIB].usRxBufPt = 0;
        }
        s_pstComCtrl[E_PORT_CALIB].pucBuf[s_pstComCtrl[E_PORT_CALIB].usRxBufPt++] = USART_RecData(M4_USART1);
        if(s_pstComCtrl[E_PORT_CALIB].usRxBufPt >= COM_MAX_BUF)
        {
            s_pstComCtrl[E_PORT_CALIB].usRxBufPt = 0;
        }
        if(s_pstComCtrl[E_PORT_CALIB].usRxLen < COM_MAX_BUF)
        {
            s_pstComCtrl[E_PORT_CALIB].usRxLen++;
        }
        s_pstComCtrl[E_PORT_CALIB].ucComStatus = E_COMM_RCVING;
        s_pstComCtrl[E_PORT_CALIB].ucIntervalCNT = RCV_BYTE_INTERVAL_TIME;
    }
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
U16 m_HD_UART_GetBuf(U8 ucChnl, U8 *pucBuf, U16 usMaxLen)
{
    U16 usRtnValue;

    usRtnValue = 0;
    if((ucChnl > E_UART_MAX) || (s_pstComCtrl[ucChnl].usRxTimeOutCnt != 0) || (usMaxLen < s_pstComCtrl[ucChnl].usRxLen))
    {
        usRtnValue = 0;
    }
    else
    {
        if(s_pstComCtrl[ucChnl].usRxLen < COM_MAX_BUF)
        {
            memcpy(pucBuf, s_pstComCtrl[ucChnl].pucBuf, s_pstComCtrl[ucChnl].usRxLen);
            usRtnValue = s_pstComCtrl[ucChnl].usRxLen;
        }
        else
        {
            usRtnValue = 0;
        }
    }

    return (usRtnValue);
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
static void UsartTxCmpltIrqCallback(void)
{
    if(USART_GetStatus(M4_USART1, UsartTxComplete) == Set)//�Զ�����
    {
        if(s_pstComCtrl[E_PORT_CALIB].usTxLen > s_pstComCtrl[E_PORT_CALIB].usTxBufPt)
        {
            USART_SendData(M4_USART1, s_pstComCtrl[E_PORT_CALIB].pucBuf[s_pstComCtrl[E_PORT_CALIB].usTxBufPt++]);
        }
        else
        {
            s_pstComCtrl[E_PORT_CALIB].usTxLen = 0;
            s_pstComCtrl[E_PORT_CALIB].usTxBufPt = 0;
            s_pstComCtrl[E_PORT_CALIB].usRxBufPt = 0;
            s_pstComCtrl[E_PORT_CALIB].usRxLen = 0;

            //USART_FuncCmd(M4_USART1, UsartTx, Disable);
            USART_FuncCmd(M4_USART1, UsartTxCmpltInt, Disable);
            USART_FuncCmd(M4_USART1, UsartRxInt, Enable);
        }
    }
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
U8 m_HD_UART_SendBuf(U8 ucChnl, U8 *pucBuf, U16 usSendLen)
{
    U8 ucRtnValue;

    ucRtnValue = true;
    if((ucChnl >= E_UART_MAX) || (usSendLen == 0) || (usSendLen >= COM_MAX_BUF) || (s_pstComCtrl[ucChnl].usTxLen == 0))
    {
        ucRtnValue = false;
    }
    else
    {
        memcpy(s_pstComCtrl[ucChnl].pucBuf, pucBuf, usSendLen);
        s_pstComCtrl[ucChnl].usTxLen = usSendLen;
        s_pstComCtrl[ucChnl].usTxBufPt = 0;

        USART_FuncCmd(M4_USART1, UsartRxInt, Disable);
        USART_FuncCmd(M4_USART1, UsartTxCmpltInt, Enable);
    }

    return (ucRtnValue);
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_UART_PwrOffInit(void)
{

}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
const U32 s_pulBaudValue[] = {300, 600, 1200, 2400, 4800, 9600, 19200, 38400};
U8 m_HD_UART_PwrOnInit(U8 ucChnl, U8 ucBaud, en_functional_state_t ucEnable)
{
    U8 ucRtnValue;
    stc_irq_regi_conf_t stcIrqRegiCfg;
    const stc_usart_uart_init_t stcInitCfg = {
    UsartIntClkCkNoOutput,
    UsartClkDiv_4,//42M/4
    UsartDataBits8,
    UsartDataLsbFirst,
    UsartOneStopBit,
    UsartParityNone,
    UsartSamleBit8,
    UsartStartBitFallEdge,
    UsartRtsEnable,
    };

    ucRtnValue = true;
    if((ucChnl >= E_UART_MAX) || (ucBaud > (sizeof(s_pulBaudValue) / sizeof(U32))))
    {
        ucRtnValue = false;
    }
    else
    {
        switch(ucChnl)
        {
            case E_UART_CALI:
            {
                /* Configuration peripheral clock */
                PWC_Fcg1PeriphClockCmd(PWC_FCG1_PERIPH_USART1 | PWC_FCG1_PERIPH_USART2 | PWC_FCG1_PERIPH_USART3 | PWC_FCG1_PERIPH_USART4, ucEnable);
                /* Initialize USART IO */
                PORT_SetFunc(TTL_RXD_PORT, TTL_RXD_PIN, Func_Usart1_Rx, Disable);
                PORT_SetFunc(TTL_TXD_PORT, TTL_TXD_PIN, Func_Usart1_Tx, Disable);

                USART_UART_Init(M4_USART1, &stcInitCfg);
                /* Set baudrate */
                if(USART_SetBaudrate(M4_USART1, s_pulBaudValue[ucBaud]) == Ok)
                {
                    /* Set USART RX IRQ */
                    stcIrqRegiCfg.enIRQn = Int000_IRQn;
                    stcIrqRegiCfg.pfnCallback = &UsartRxIrqCallback;
                    stcIrqRegiCfg.enIntSrc = INT_USART1_RI;
                    enIrqRegistration(&stcIrqRegiCfg);
                    NVIC_SetPriority(stcIrqRegiCfg.enIRQn, DDL_IRQ_PRIORITY_DEFAULT);
                    NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
                    NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);

                    stcIrqRegiCfg.enIRQn = Int001_IRQn;
                    stcIrqRegiCfg.pfnCallback = &UsartTxCmpltIrqCallback;
                    stcIrqRegiCfg.enIntSrc = INT_USART1_TCI;
                    enIrqRegistration(&stcIrqRegiCfg);
                    NVIC_SetPriority(stcIrqRegiCfg.enIRQn, DDL_IRQ_PRIORITY_DEFAULT);
                    NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
                    NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);

                    /*Enable RX && RX interupt function*/
                    USART_FuncCmd(M4_USART1, UsartRx, Enable);
                    USART_FuncCmd(M4_USART1, UsartTx, Enable);
                    USART_FuncCmd(M4_USART1, UsartRxInt, Enable);
                }
                else
                {
                    ucRtnValue = false;
                }
            }break;
            default:
            {

            }break;
        }
    }

    return (ucRtnValue);
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_UART_TimeMechanism(U8 ucPeriod)
{
    U8 ucChnl;

    for(ucChnl = 0; ucChnl < E_UART_MAX; ucChnl++)
    {
        if(s_pstComCtrl[ucChnl].usRxTimeOutCnt > ucPeriod)
        {
            s_pstComCtrl[ucChnl].usRxTimeOutCnt -= ucPeriod;
        }
        else if(s_pstComCtrl[ucChnl].usRxTimeOutCnt)
        {
            s_pstComCtrl[ucChnl].usRxTimeOutCnt = 0;
        }
    }
}


