/*
*****************************************************************************
 Copyright (C)
 Module         : DMA��ز���
 File Name      : m_HD_DMA.c
 Description    :
 others         :
 Meter Type     ��
 ----------------------------------------------------------------------------
 Modification History:
 <No.> <version >  <time>        <author>     <contents>

******************************************************************************
*/
#define   __M_HD_DMA_C__

/****************************************************************************/
/* ����ͷ�ļ� */

#ifndef   Debug_M_HD_DMA_err
#define   Debug_M_HD_DMA_err(n)
#endif

#include "m_HD_DMA.h"
#include <stdlib.h>
#include "m_Measure.h"
#include "m_MCP391x.h"
#include "CALI_protocol.h"
#include "m_TTU_Protocol.h"

/*****************************************************************************
 * prototypes define  *
 ****************************************************************************/

/*****************************************************************************
        TYPE AND CONSTANT
*****************************************************************************/


/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_DMA2_SPISt(U8 ucEnable)
{
    U32 ulAddr;
    U16 usLen;

    if(ucEnable == Enable)
    {
        SPI_ClearFlag(M4_SPI4, SpiFlagReceiveBufferFull);
        SPI_ClearFlag(M4_SPI4, SpiFlagSendBufferEmpty);
        SPI_ClearFlag(M4_SPI4, SpiFlagUnderloadError);
        SPI_ClearFlag(M4_SPI4, SpiFlagParityError);
        SPI_ClearFlag(M4_SPI4, SpiFlagModeFaultError);
        SPI_ClearFlag(M4_SPI4, SpiFlagSpiIdle);
        SPI_ClearFlag(M4_SPI4, SpiFlagOverloadError);

        usLen = m_TTU_GetSndBuf(&ulAddr);
        DMA_SetSrcAddress(M4_DMA2, DmaCh0, ulAddr);
        DMA_SetTransferCnt(M4_DMA2, DmaCh0, usLen);
        usLen = m_TTU_GetRcvBuf(&ulAddr);
        DMA_SetDesAddress(M4_DMA2, DmaCh1, ulAddr);
        DMA_SetTransferCnt(M4_DMA2, DmaCh1, usLen);
        DMA_ChannelCmd(M4_DMA2, DmaCh0, Enable);
        DMA_ChannelCmd(M4_DMA2, DmaCh1, Enable);

        SPI_Cmd(M4_SPI4, Enable);
    }
    else
    {
        DMA_ChannelCmd(M4_DMA2, DmaCh0, Disable);
        DMA_ChannelCmd(M4_DMA2, DmaCh1, Disable);
        SPI_ClearFlag(M4_SPI4, SpiFlagReceiveBufferFull);
        SPI_ClearFlag(M4_SPI4, SpiFlagSendBufferEmpty);
        SPI_ClearFlag(M4_SPI4, SpiFlagUnderloadError);
        SPI_ClearFlag(M4_SPI4, SpiFlagParityError);
        SPI_ClearFlag(M4_SPI4, SpiFlagModeFaultError);
        SPI_ClearFlag(M4_SPI4, SpiFlagSpiIdle);
        SPI_ClearFlag(M4_SPI4, SpiFlagOverloadError);
        SPI_Cmd(M4_SPI4, Disable);
    }
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
#define SELF_CHECK_ERROR_CNT  5
void SPIx_DMA_RX_CallBack(void)
{
    U32 ulTmpData;
    U8  ucCnt1;

    if(((M4_DMA1->INTSTAT1 & (1ul << (DmaCh1)))? Set : Reset) == Set)
    //if(DMA_GetIrqFlag(M4_DMA1, DmaCh1, TrnCpltIrq) == Set)
    {
        M4_DMA1->INTCLR1 |= (1ul << (DmaCh1));
        M4_DMA1->INTCLR1 |= (1ul << (DmaCh0));
        //DMA_ClearIrqFlag(M4_DMA1, DmaCh0, TrnCpltIrq);
        //DMA_ClearIrqFlag(M4_DMA1, DmaCh1, TrnCpltIrq);
        M4_SPI2->CR1_f.SPE = Disable;
        //SPI_Cmd(M4_SPI2, Disable);
        M_CS_H;

        if(gstSpiData.ucSpiReadType == SPI_READ_INSTANCE_DATA)
        {
            m_MCP391x_GetSmpPint(g_pucSPIRec + 1);
            memset(g_pucSPISnd, 0, BUFFER_SIZE);
            g_pucSPISnd[0] = m_MCP391x_GetChkRegAddr();
            g_pucSPISnd[0] = (g_pucSPISnd[0] << 1) | 0x41;
            M_CS_L;
            M4_DMA1->SAR0 = (U32)(&g_pucSPISnd[0]);
            M4_DMA1->DTCTL0 = (M4_DMA1->DTCTL0 & 0x0000ffff) | (4 << 16);
            //DMA_SetSrcAddress(M4_DMA1, DmaCh0, (U32)(&g_pucSPISnd[0]));
            //DMA_SetTransferCnt(M4_DMA1, DmaCh0, 4);
            M4_DMA1->DAR1 = (U32)(&g_pucSPIRec[0]);
            M4_DMA1->DTCTL1 = (M4_DMA1->DTCTL1 & 0x0000ffff) | (4 << 16);
            //DMA_SetDesAddress(M4_DMA1, DmaCh1, (U32)(&g_pucSPIRec[0]));
            //DMA_SetTransferCnt(M4_DMA1, DmaCh1, 4);
            M4_DMA1->CHEN |= (1ul << (DmaCh0)) & 0x0fu;
            M4_DMA1->CHEN |= (1ul << (DmaCh1)) & 0x0fu;
            //DMA_ChannelCmd(M4_DMA1, DmaCh0, Enable);
            //DMA_ChannelCmd(M4_DMA1, DmaCh1, Enable);

            M4_SPI2->CR1_f.SPE = Enable;
            //SPI_Cmd(M4_SPI2, Enable);
            //MCP391x_Read391x_SPI_DMA(pucSelfCheckRegisterAddr[gstSpiData.ucSelfCheckRegister], 4);
            gstSpiData.ucSpiReadType = SPI_READ_OTHER_REGISTER;
        }
        else if(gstSpiData.ucSpiReadType == SPI_READ_OTHER_REGISTER)/*�жϼĴ���ֵ�Ƿ���ȷ*/
        {
            ulTmpData = 0;
            ucCnt1 = 0;
            ulTmpData |= g_pucSPIRec[ucCnt1 + 1];
            ulTmpData <<= 8;
            ulTmpData |= g_pucSPIRec[ucCnt1 + 2];
            ulTmpData <<= 8;
            ulTmpData |= g_pucSPIRec[ucCnt1 + 3];
            if(m_MCP391x_ChkReg(g_pucSPIRec + 1) != true)
            {

            }
        }
    }
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_DMA_Init(void)
{
    stc_dma_config_t stcDmaCfg;
    stc_irq_regi_conf_t stcIrqRegiCfg;
    NVIC_InitTypeDef NVIC_InitStructure;

    PWC_Fcg0PeriphClockCmd(PWC_FCG0_PERIPH_DMA1, Enable);
        /* Enable PTDIS(AOS) clock*/
    PWC_Fcg0PeriphClockCmd(PWC_FCG0_PERIPH_PTDIS, Enable);

    MEM_ZERO_STRUCT(stcDmaCfg);
    MEM_ZERO_STRUCT(stcIrqRegiCfg);

    /* Configure TX DMA */
    /* Set data block size. */
    stcDmaCfg.u16BlockSize = 1;
    /* Set transfer count. */
    stcDmaCfg.u16TransferCnt = BUFFER_SIZE;
    /* Set source & destination address. */
    stcDmaCfg.u32SrcAddr = (U32)(&g_pucSPISnd[0]);
    stcDmaCfg.u32DesAddr = (U32)(&M4_SPI2->DR);

    stcDmaCfg.stcDmaChCfg.enIntEn = Disable;
    /* Set source & destination address mode. */
    stcDmaCfg.stcDmaChCfg.enSrcInc = AddressIncrease;
    stcDmaCfg.stcDmaChCfg.enDesInc = AddressFix;
    /* Set data width 32bit. */
    stcDmaCfg.stcDmaChCfg.enTrnWidth = Dma8Bit;
    /* Init Dma channel. */
    DMA_InitChannel(M4_DMA1, DmaCh0, &stcDmaCfg);

    /* Configure RX DMA */
    /* Set data block size. */
    stcDmaCfg.u16BlockSize = 1;
    /* Set transfer count. */
    stcDmaCfg.u16TransferCnt = BUFFER_SIZE;
    /* Set source & destination address. */
    stcDmaCfg.u32SrcAddr = (U32)(&M4_SPI2->DR);
    stcDmaCfg.u32DesAddr = (U32)(&g_pucSPIRec[0]);

    stcDmaCfg.stcDmaChCfg.enIntEn = Enable;
    /* Set source & destination address mode. */
    stcDmaCfg.stcDmaChCfg.enSrcInc = AddressFix;
    stcDmaCfg.stcDmaChCfg.enDesInc = AddressIncrease;
    /* Set data width 32bit. */
    stcDmaCfg.stcDmaChCfg.enTrnWidth = Dma8Bit;
    /* Init Dma channel. */
    DMA_InitChannel(M4_DMA1, DmaCh1, &stcDmaCfg);

    /* Set dma trigger source. */
    DMA_SetTriggerSrc(M4_DMA1, DmaCh0, EVT_SPI2_SRTI);
    /* Set dma trigger source. */
    DMA_SetTriggerSrc(M4_DMA1, DmaCh1, EVT_SPI2_SRRI);
    /*  Clear interrupt flag  */
    DMA_ClearIrqFlag(M4_DMA1, DmaCh0, TrnCpltIrq);
    /*  Clear interrupt flag  */
    DMA_ClearIrqFlag(M4_DMA1, DmaCh1, TrnCpltIrq);

    stcIrqRegiCfg.enIRQn = Int003_IRQn;
    stcIrqRegiCfg.pfnCallback = &SPIx_DMA_RX_CallBack;
    stcIrqRegiCfg.enIntSrc = INT_DMA1_TC1;
    enIrqRegistration(&stcIrqRegiCfg);
    //NVIC_SetPriority(stcIrqRegiCfg.enIRQn, DDL_IRQ_PRIORITY_00);
    //NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
    //NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);

    NVIC_InitStructure.NVIC_IRQChannel = Int003_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0 ;//��ռ���ȼ�0
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;		//�����ȼ�1
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
	NVIC_Init(&NVIC_InitStructure);
    DMA_Cmd(M4_DMA1, Enable);
}
/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_DMA_DeInit(void)
{
    stc_dma_config_t stcDmaCfg;
    stc_irq_regi_conf_t stcIrqRegiCfg;

    PWC_Fcg0PeriphClockCmd(PWC_FCG0_PERIPH_DMA1, Enable);
        /* Enable PTDIS(AOS) clock*/
    PWC_Fcg0PeriphClockCmd(PWC_FCG0_PERIPH_PTDIS, Enable);

    MEM_ZERO_STRUCT(stcDmaCfg);
    MEM_ZERO_STRUCT(stcIrqRegiCfg);

    /* Configure TX DMA */
    /* Set data block size. */
    stcDmaCfg.u16BlockSize = 1;
    /* Set transfer count. */
    stcDmaCfg.u16TransferCnt = BUFFER_SIZE;
    /* Set source & destination address. */
    stcDmaCfg.u32SrcAddr = (U32)(&g_pucSPISnd[0]);
    stcDmaCfg.u32DesAddr = (U32)(&M4_SPI2->DR);

    stcDmaCfg.stcDmaChCfg.enIntEn = Disable;
    /* Set source & destination address mode. */
    stcDmaCfg.stcDmaChCfg.enSrcInc = AddressIncrease;
    stcDmaCfg.stcDmaChCfg.enDesInc = AddressFix;
    /* Set data width 32bit. */
    stcDmaCfg.stcDmaChCfg.enTrnWidth = Dma8Bit;
    /* Init Dma channel. */
    DMA_InitChannel(M4_DMA1, DmaCh0, &stcDmaCfg);

    /* Configure RX DMA */
    /* Set data block size. */
    stcDmaCfg.u16BlockSize = 1;
    /* Set transfer count. */
    stcDmaCfg.u16TransferCnt = BUFFER_SIZE;
    /* Set source & destination address. */
    stcDmaCfg.u32SrcAddr = (U32)(&M4_SPI2->DR);
    stcDmaCfg.u32DesAddr = (U32)(&g_pucSPIRec[0]);

    stcDmaCfg.stcDmaChCfg.enIntEn = Disable;
    /* Set source & destination address mode. */
    stcDmaCfg.stcDmaChCfg.enSrcInc = AddressFix;
    stcDmaCfg.stcDmaChCfg.enDesInc = AddressIncrease;
    /* Set data width 32bit. */
    stcDmaCfg.stcDmaChCfg.enTrnWidth = Dma8Bit;
    /* Init Dma channel. */
    DMA_InitChannel(M4_DMA1, DmaCh1, &stcDmaCfg);
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_DMA2_Init(void)
{
    stc_dma_config_t stcDmaCfg;
    U32              ulAddr;

    PWC_Fcg0PeriphClockCmd(PWC_FCG0_PERIPH_DMA2, Enable);
        /* Enable PTDIS(AOS) clock*/
    PWC_Fcg0PeriphClockCmd(PWC_FCG0_PERIPH_PTDIS, Enable);

    MEM_ZERO_STRUCT(stcDmaCfg);

    /* Configure TX DMA */
    /* Set data block size. */
    stcDmaCfg.u16BlockSize = 1;
    /* Set transfer count. */
    stcDmaCfg.u16TransferCnt = m_TTU_GetSndBuf(&ulAddr);
    /* Set source & destination address. */
    stcDmaCfg.u32SrcAddr = ulAddr;
    stcDmaCfg.u32DesAddr = (U32)(&M4_SPI4->DR);
    stcDmaCfg.stcDmaChCfg.enIntEn = Enable;
    /* Set source & destination address mode. */
    stcDmaCfg.stcDmaChCfg.enSrcInc = AddressIncrease;
    stcDmaCfg.stcDmaChCfg.enDesInc = AddressFix;
    /* Set data width 32bit. */
    stcDmaCfg.stcDmaChCfg.enTrnWidth = Dma8Bit;
    /* Init Dma channel. */
    DMA_InitChannel(M4_DMA2, DmaCh0, &stcDmaCfg);

    /* Configure RX DMA */
    /* Set data block size. */
    stcDmaCfg.u16BlockSize = 1;
    /* Set transfer count. */
    stcDmaCfg.u16TransferCnt = m_TTU_GetRcvBuf(&ulAddr);
    /* Set source & destination address. */
    stcDmaCfg.u32SrcAddr = (U32)(&M4_SPI4->DR);
    stcDmaCfg.u32DesAddr = ulAddr;
    stcDmaCfg.stcDmaChCfg.enIntEn = Disable;
    /* Set source & destination address mode. */
    stcDmaCfg.stcDmaChCfg.enSrcInc = AddressFix;
    stcDmaCfg.stcDmaChCfg.enDesInc = AddressIncrease;
    /* Set data width 32bit. */
    stcDmaCfg.stcDmaChCfg.enTrnWidth = Dma8Bit;
    /* Init Dma channel. */
    DMA_InitChannel(M4_DMA2, DmaCh1, &stcDmaCfg);

    DMA_SetTriggerSrc(M4_DMA2, DmaCh0, EVT_SPI4_SRTI);
    DMA_SetTriggerSrc(M4_DMA2, DmaCh1, EVT_SPI4_SRRI);

    DMA_Cmd(M4_DMA2, Enable);
    m_HD_DMA2_SPISt(Enable);
}


