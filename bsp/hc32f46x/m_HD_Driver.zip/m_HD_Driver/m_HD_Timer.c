/*
*****************************************************************************
 Copyright (C)
 Module         : ��ʱ����ز���
 File Name      : m_HD_Timer.c
 Description    :
 others         :
 Meter Type     ��
 ----------------------------------------------------------------------------
 Modification History:
 <No.> <version >  <time>        <author>     <contents>

******************************************************************************
*/
#define   __M_HD_TIMER_C__

/****************************************************************************/
/* ����ͷ�ļ� */

#ifndef   Debug_M_HD_TIMER_err
#define   Debug_M_HD_TIMER_err(n)
#endif

#include "m_HD_Timer.h"
#include "m_MISC.h"
#include "m_HD_DMA.h"
#include "MTR_UAL.h"
/*****************************************************************************
 * prototypes define  *
 ****************************************************************************/

/*****************************************************************************
        TYPE AND CONSTANT
*****************************************************************************/
void Timer01B_CallBack(void)
{
    if(TIMER0_GetFlag(M4_TMR01, Tim0_ChannelB) == Set)
    {
        g_stTaskCnt.usPro160msCnt++;
        //PORT_Toggle(M_SDO_PORT, M_SDO_PIN);
        CM_StateTimingProcess();
        //m_CM_RcvPro(g_pucSPISlaveRec, sizeof(g_pucSPISlaveRec));
    }
}
void Timer02B_CallBack(void)
{
    if(TIMER0_GetFlag(M4_TMR02, Tim0_ChannelB) == Set)
    {
        //MTR_PulseOutput();
    }
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_Timer02_PwrOn(void)
{
    stc_tim0_base_init_t stcTimerCfg;
    stc_irq_regi_conf_t  stcIrqRegiConf;
    uint32_t u32Pclk1;
    stc_clk_freq_t stcClkTmp;

    MEM_ZERO_STRUCT(stcTimerCfg);
    MEM_ZERO_STRUCT(stcIrqRegiConf);

    /* Get pclk1 */
    CLK_GetClockFreq(&stcClkTmp);
    u32Pclk1 = stcClkTmp.pclk1Freq;

    PWC_Fcg2PeriphClockCmd(PWC_FCG2_PERIPH_TIM02, Enable);
    stcTimerCfg.Tim0_CounterMode = Tim0_Sync;
    stcTimerCfg.Tim0_SyncClockSource = Tim0_Pclk1;//42000000
    stcTimerCfg.Tim0_ClockDivision = Tim0_ClkDiv0;
    stcTimerCfg.Tim0_CmpValue = (U16)(u32Pclk1 * 0.00015625 / 1 - 1);//��ʱ0.00125s
    TIMER0_BaseInit(M4_TMR02, Tim0_ChannelB, &stcTimerCfg);

    /* Enable channel A interrupt */
    TIMER0_IntCmd(M4_TMR02, Tim0_ChannelB, Enable);
    /* Register TMR_INI_GCMA Int to Vect.No.001 */
    stcIrqRegiConf.enIRQn = Int010_IRQn;
    /* Select I2C Error or Event interrupt function */
    stcIrqRegiConf.enIntSrc = INT_TMR02_GCMB;
    /* Callback function */
    stcIrqRegiConf.pfnCallback = &Timer02B_CallBack;
    /* Registration IRQ */
    enIrqRegistration(&stcIrqRegiConf);
    /* Clear Pending */
    NVIC_ClearPendingIRQ(stcIrqRegiConf.enIRQn);
    /* Set priority */
    NVIC_SetPriority(stcIrqRegiConf.enIRQn, DDL_IRQ_PRIORITY_00);
    /* Enable NVIC */
    NVIC_EnableIRQ(stcIrqRegiConf.enIRQn);

    TIMER0_Cmd(M4_TMR02, Tim0_ChannelB,Enable);
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_Timer01_PwrOn(void)
{
    stc_tim0_base_init_t stcTimerCfg;
    stc_irq_regi_conf_t  stcIrqRegiConf;
    uint32_t u32Pclk1;
    stc_clk_freq_t stcClkTmp;

    MEM_ZERO_STRUCT(stcTimerCfg);
    MEM_ZERO_STRUCT(stcIrqRegiConf);

    /* Get pclk1 */
    CLK_GetClockFreq(&stcClkTmp);
    u32Pclk1 = stcClkTmp.pclk1Freq;

    PWC_Fcg2PeriphClockCmd(PWC_FCG2_PERIPH_TIM01, Enable);
    stcTimerCfg.Tim0_CounterMode = Tim0_Sync;
    stcTimerCfg.Tim0_SyncClockSource = Tim0_Pclk1;//42000000
    stcTimerCfg.Tim0_ClockDivision = Tim0_ClkDiv0;
    stcTimerCfg.Tim0_CmpValue = (U16)(u32Pclk1 * 0.00125 / 1 - 1);//��ʱ0.00125s
    TIMER0_BaseInit(M4_TMR01, Tim0_ChannelB, &stcTimerCfg);

    /* Enable channel A interrupt */
    TIMER0_IntCmd(M4_TMR01, Tim0_ChannelB, Enable);
    /* Register TMR_INI_GCMA Int to Vect.No.001 */
    stcIrqRegiConf.enIRQn = Int002_IRQn;
    /* Select I2C Error or Event interrupt function */
    stcIrqRegiConf.enIntSrc = INT_TMR01_GCMB;
    /* Callback function */
    stcIrqRegiConf.pfnCallback = &Timer01B_CallBack;
    /* Registration IRQ */
    enIrqRegistration(&stcIrqRegiConf);
    /* Clear Pending */
    NVIC_ClearPendingIRQ(stcIrqRegiConf.enIRQn);
    /* Set priority */
    NVIC_SetPriority(stcIrqRegiConf.enIRQn, DDL_IRQ_PRIORITY_00);
    /* Enable NVIC */
    NVIC_EnableIRQ(stcIrqRegiConf.enIRQn);

    TIMER0_Cmd(M4_TMR01, Tim0_ChannelB,Enable);
}
/********************************************************************************
Function name:
Description:    clk / 6.5536 / 4 = 13
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_Timer63_PwrOn(void)
{
    U16   u16Period;
    U16   u16Compare;
    stc_timer6_basecnt_cfg_t         stcTIM6BaseCntCfg;
    stc_timer6_port_output_cfg_t     stcTIM6PWMxCfg;
    stc_timer6_gcmp_buf_cfg_t        stcGCMPBufCfg;
    stc_irq_regi_conf_t              stcIrqRegiConf;
    stc_clk_freq_t stcClkTmp;


    MEM_ZERO_STRUCT(stcTIM6BaseCntCfg);
    MEM_ZERO_STRUCT(stcTIM6PWMxCfg);
    MEM_ZERO_STRUCT(stcGCMPBufCfg);
    MEM_ZERO_STRUCT(stcIrqRegiConf);

    /* Get pclk1 */
    CLK_GetClockFreq(&stcClkTmp);

    PWC_Fcg2PeriphClockCmd(PWC_FCG2_PERIPH_TIM63, Enable);
    //PWC_Fcg0PeriphClockCmd(PWC_FCG0_PERIPH_PTDIS, Enable);

    PORT_SetFunc(M_PWM_CLK_PORT, M_PWM_CLK_PIN, Func_Tim6, Disable);    //Timer63 PWMA

    stcTIM6BaseCntCfg.enCntMode   = Timer6CntSawtoothMode;              //Sawtooth wave mode
    stcTIM6BaseCntCfg.enCntDir    = Timer6CntDirUp;                     //Counter counting up
    stcTIM6BaseCntCfg.enCntClkDiv = Timer6PclkDiv1;                     //Count clock: pclk0
    Timer6_Init(M4_TMR63, &stcTIM6BaseCntCfg);                          //timer6 PWM frequency, count mode and clk config

    u16Period = 12;
    //Timer6_SetPeriod(M4_TMR63, Timer6PeriodB, u16Period);               //period set
    Timer6_SetPeriod(M4_TMR63, Timer6PeriodA, u16Period);               //period set

    u16Compare = 10u;
    Timer6_SetGeneralCmpValue(M4_TMR63, Timer6GenCompareB, u16Compare);    //Set General Compare RegisterA Value

    stcTIM6PWMxCfg.enPortMode = Timer6ModeCompareOutput;    //Compare output function
    stcTIM6PWMxCfg.bOutEn     = true;                       //Output enable
    stcTIM6PWMxCfg.enPerc     = Timer6PWMxCompareKeep;       //PWMA port output Low level when CNTER value match PERAR
    stcTIM6PWMxCfg.enCmpc     = Timer6PWMxCompareInv;      //PWMA port output High level when CNTER value match with GCMAR
    stcTIM6PWMxCfg.enStaStp   = Timer6PWMxStateSelSS;       //PWMA output status is decide by STACA STPCA when CNTER start and stop
    stcTIM6PWMxCfg.enStaOut   = Timer6PWMxPortOutLow;       //PWMA port output set low level when CNTER start
    stcTIM6PWMxCfg.enStpOut   = Timer6PWMxPortOutLow;       //PWMA port output set low level when CNTER stop
    stcTIM6PWMxCfg.enDisVal   = Timer6PWMxDisValLow;
    Timer6_PortOutputConfig(M4_TMR63, Timer6PWMB, &stcTIM6PWMxCfg);

    /*start timer6*/
    Timer6_StartCount(M4_TMR63);
}

