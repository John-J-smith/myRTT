/*
*****************************************************************************
 Copyright (C)
 Module         :
 File Name      :
 Description    :
 others         :
 Meter Type     ��
 ----------------------------------------------------------------------------
 Modification History:
 <No.> <version >  <time>        <author>     <contents>

******************************************************************************
*/
#define   __M_HD_PVD_C__

/****************************************************************************/
/* ����ͷ�ļ� */

#ifndef   Debug_M_HD_PVD_err
#define   Debug_M_HD_PVD_err(n)
#endif

#include "m_HD_PVD.h"
/*****************************************************************************
 * prototypes define  *
 ****************************************************************************/
__IO uint16_t u16cmp2 = 0u;

/*****************************************************************************
        TYPE AND CONSTANT
*****************************************************************************/
/********************************************************************************
Function name:
Description:

Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
static void Pvd2_IrqHandler(void)
{
    u16cmp2++;
}
/********************************************************************************
Function name:
Description:

Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_PVD_Config(void)
{
    stc_pwc_pvd_cfg_t   stcPwcPvdCfg;
    stc_nmi_config_t    stcNmiCfd;

    MEM_ZERO_STRUCT(stcPwcPvdCfg);
    //MEM_ZERO_STRUCT(stcNmiCfd);

    PWR_FAIL_DT_INPUT;

    /* Config PVD2.*/
    /* Disable filter. */
    stcPwcPvdCfg.enPvd2FilterEn = Disable;

    /* Non-Msk interrupt. */
    stcPwcPvdCfg.enPvd2Int = NonMskInt;

    /* Interrupt. */
    stcPwcPvdCfg.stcPvd2Ctl.enPvdMode = PvdInt;

    /* Enable Pvd2 interrupt. */
    stcPwcPvdCfg.stcPvd2Ctl.enPvdIREn = Enable;

    /* Enable output compared result. */
    stcPwcPvdCfg.stcPvd2Ctl.enPvdCmpOutEn = Enable;

    /* PVD2 Threshold Voltage 1.1V. */
    stcPwcPvdCfg.enPvd2Level = Pvd2Level11;

    PWC_PvdCfg(&stcPwcPvdCfg);

    /* Config NMI.*/
    /* Set PVD2 as NMI source. */
    stcNmiCfd.u16NmiSrc = NmiSrcVdu2;
    /* Disbale filter. */
    stcNmiCfd.enFilterEn = Disable;
    /* Set Pvd2 interrupt callback. */
    stcNmiCfd.pfnNmiCallback = &Pvd2_IrqHandler;

    NMI_Init(&stcNmiCfd);

    /* Enable external vcc. */
    PWC_ExVccCmd(Enable);

    /* Enable PVD2. */
    PWC_Pvd2Cmd(Enable);
}


