/*
*****************************************************************************
 Copyright (C)
 Module         : GPIO��ز���
 File Name      : m_HD_GPIO.c
 Description    :
 others         :
 Meter Type     ��
 ----------------------------------------------------------------------------
 Modification History:
 <No.> <version >  <time>        <author>     <contents>

******************************************************************************
*/
#define   __M_HD_GPIO_C__

/****************************************************************************/
/* ����ͷ�ļ� */

#ifndef   Debug_M_HD_GPIO_err
#define   Debug_M_HD_GPIO_err(n)
#endif

#include "m_HD_GPIO.h"
#include "m_MCP391x.h"
#include "m_Measure.h"
#include "m_HD_DMA.h"
#include "m_MISC.h"
#include "m_TTU_Protocol.h"

/*****************************************************************************
 * prototypes define  *
 ****************************************************************************/

/*****************************************************************************
        TYPE AND CONSTANT
*****************************************************************************/
/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void ExtInt10_Callback(void)
{
    if(Set == (1u == !!(M4_INTC->EIFR & (1ul<<ExtiCh10)) ? Set : Reset))
    //if (Set == EXINT_IrqFlgGet(ExtiCh10))
    {
        /* clear int request flag */
        M4_INTC->EICFR |= (U32)(1ul << ExtiCh10);//EXINT_IrqFlgClr(ExtiCh10);
        memset(g_pucSPISnd, 0, BUFFER_SIZE);
        g_pucSPISnd[0] = m_MCP391x_GetDataAddr();
        g_pucSPISnd[0] = (g_pucSPISnd[0] << 1) | 0x41;
        M_CS_L;
        M4_DMA1->SAR0 = (U32)(&g_pucSPISnd[0]);
        M4_DMA1->DTCTL0 = (M4_DMA1->DTCTL0 & 0x0000ffff) | (25 << 16);
        //DMA_SetSrcAddress(M4_DMA1, DmaCh0, (U32)(&g_pucSPISnd[0]));
        //DMA_SetTransferCnt(M4_DMA1, DmaCh0, 7);
        M4_DMA1->DAR1 = (U32)(&g_pucSPIRec[0]);
        M4_DMA1->DTCTL1 = (M4_DMA1->DTCTL1 & 0x0000ffff) | (25 << 16);
        //DMA_SetDesAddress(M4_DMA1, DmaCh1, (U32)(&g_pucSPIRec[0]));
        //DMA_SetTransferCnt(M4_DMA1, DmaCh1, 7);

        //DMA_ChannelCmd(M4_DMA1, DmaCh0, Enable);
        //DMA_ChannelCmd(M4_DMA1, DmaCh1, Enable);

        M4_DMA1->CHEN |= (1ul << (0)) & 0x0fu;
        M4_DMA1->CHEN |= (1ul << (1)) & 0x0fu;

        M4_SPI2->CR1_f.SPE = Enable;

        gstSpiData.ucSpiReadType = SPI_READ_INSTANCE_DATA;

        //SPI_Cmd(M4_SPI2, Enable);
        //MCP391x_Read391x_SPI_DMA(0x00, 25);
    }
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void ExtInt7_Callback(void)
{
    if(Set == (1u == !!(M4_INTC->EIFR & (1ul<<ExtiCh07)) ? Set : Reset))
    //if (Set == EXINT_IrqFlgGet(ExtiCh10))
    {
        /* clear int request flag */
        M4_INTC->EICFR |= (U32)(1ul << ExtiCh07);//EXINT_IrqFlgClr(ExtiCh10);
        m_TTU_Mechansim();
        DMA_Cmd(M4_DMA2, Enable);
        m_HD_DMA2_SPISt(Disable);
        m_HD_DMA2_SPISt(Enable);
    }
}
/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_EXIT_DR_DeInit(void)
{
    stc_port_init_t stcPortInit;

    MEM_ZERO_STRUCT(stcPortInit);

    /* Set PB10 as External Int Ch.10 input */
    MEM_ZERO_STRUCT(stcPortInit);
    stcPortInit.enExInt = Disable;
    PORT_Init(M_DR_INT_PORT, M_DR_INT_PIN, &stcPortInit);
}
/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_EXIT_DR_Init(void)
{
    stc_exint_config_t stcExtiConfig;
    stc_irq_regi_conf_t stcIrqRegiConf;
    stc_port_init_t stcPortInit;
    NVIC_InitTypeDef NVIC_InitStructure;

    /* configuration structure initialization */
    MEM_ZERO_STRUCT(stcExtiConfig);
    MEM_ZERO_STRUCT(stcIrqRegiConf);
    MEM_ZERO_STRUCT(stcPortInit);

    stcExtiConfig.enExitCh = ExtiCh10;

    /* Filter setting */
    stcExtiConfig.enFilterEn = Disable;
    stcExtiConfig.enFltClk = Pclk3Div8;
    /* Both edge */
    stcExtiConfig.enExtiLvl = ExIntFallingEdge;
    EXINT_Init(&stcExtiConfig);

    /* Set PB10 as External Int Ch.10 input */
    MEM_ZERO_STRUCT(stcPortInit);
    stcPortInit.enExInt = Enable;
    PORT_Init(M_DR_INT_PORT, M_DR_INT_PIN, &stcPortInit);

    /* Select External Int Ch.3 */
    stcIrqRegiConf.enIntSrc = INT_PORT_EIRQ10;

    /* Register External Int to Vect.No.000 */
    stcIrqRegiConf.enIRQn = Int005_IRQn;
    /* Callback function */
    stcIrqRegiConf.pfnCallback = &ExtInt10_Callback;
    /* Registration IRQ */
    enIrqRegistration(&stcIrqRegiConf);

    /* Clear pending */
    //NVIC_ClearPendingIRQ(stcIrqRegiConf.enIRQn);
    /* Set priority */
    //NVIC_SetPriority(stcIrqRegiConf.enIRQn, DDL_IRQ_PRIORITY_15);
    /* Enable NVIC */
    //NVIC_EnableIRQ(stcIrqRegiConf.enIRQn);

    NVIC_InitStructure.NVIC_IRQChannel = Int005_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0 ;//��ռ���ȼ�0
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;		//�����ȼ�0
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
	NVIC_Init(&NVIC_InitStructure);
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_EXIT_SPISlave_Init(void)
{
    stc_exint_config_t stcExtiConfig;
    stc_irq_regi_conf_t stcIrqRegiConf;
    stc_port_init_t stcPortInit;
    NVIC_InitTypeDef NVIC_InitStructure;

    /* configuration structure initialization */
    MEM_ZERO_STRUCT(stcExtiConfig);
    MEM_ZERO_STRUCT(stcIrqRegiConf);
    MEM_ZERO_STRUCT(stcPortInit);

    stcExtiConfig.enExitCh = ExtiCh07;

    /* Filter setting */
    stcExtiConfig.enFilterEn = Disable;
    stcExtiConfig.enFltClk = Pclk3Div8;
    /* Both edge */
    stcExtiConfig.enExtiLvl = ExIntRisingEdge;
    EXINT_Init(&stcExtiConfig);

    /* Set PB10 as External Int Ch.10 input */
    MEM_ZERO_STRUCT(stcPortInit);
    stcPortInit.enExInt = Enable;
    PORT_Init(SLAVE_SPI_CS_PORT, SLAVE_SPI_CS_PIN, &stcPortInit);

    /* Select External Int Ch.3 */
    stcIrqRegiConf.enIntSrc = INT_PORT_EIRQ7;

    /* Register External Int to Vect.No.000 */
    stcIrqRegiConf.enIRQn = Int006_IRQn;
    /* Callback function */
    stcIrqRegiConf.pfnCallback = &ExtInt7_Callback;
    /* Registration IRQ */
    enIrqRegistration(&stcIrqRegiConf);

    /* Clear pending */
    //NVIC_ClearPendingIRQ(stcIrqRegiConf.enIRQn);
    /* Set priority */
    //NVIC_SetPriority(stcIrqRegiConf.enIRQn, DDL_IRQ_PRIORITY_15);
    /* Enable NVIC */
    //NVIC_EnableIRQ(stcIrqRegiConf.enIRQn);

    NVIC_InitStructure.NVIC_IRQChannel = Int006_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3 ;//��ռ���ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;		//�����ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
	NVIC_Init(&NVIC_InitStructure);
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_GPIO_PinMode(en_port_t enPort, en_pin_t u16Pin, en_pin_mode_t pinMode, en_functional_state_t enNewState)
{
    stc_port_init_t stPortInit;
    /* configuration structure initialization */
    MEM_ZERO_STRUCT(stPortInit);

    stPortInit.enPinMode = pinMode;
    stPortInit.enPullUp = enNewState;

    PORT_Init(enPort, u16Pin, &stPortInit);
}


/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_GPIO_Init(void)
{

}
/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_3914_PwrOnInit(void)
{
    /* 3914 Power Open */
    M_PWR_CT_L;M_PWR_CT_OUTPUT;M_PWR_CT_L;
    m_MISC_Dlyms(5);

    /* 3914 Clk Open */
    //M_PWM_CLK_H;M_PWM_CLK_OUTPUT;M_PWM_CLK_H;

    /* 3914 RST Open */
    M_RST_L;M_RST_OUTPUT;M_RST_L;
    m_MISC_Dlyms(5);
    M_RST_H;
    m_MISC_Dlyms(5);
    /* 3914 CS Close */
    M_CS_H;M_CS_OUTPUT;M_CS_H;
    M_SDI_INPUT;
    M_SDO_H;M_SDO_OUTPUT;M_SDO_H;
    M_SCK_H;M_SCK_OUTPUT;M_SCK_H;
    M_DR_INT_INPUT;
    m_HD_GPIO_PinMode(SLAVE_SPI_MISO_PORT, SLAVE_SPI_MISO_PIN, Pin_Mode_Out, Enable);
}
/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_3914_PwrOffInit(void)
{
    /* 3914 init */
    /* 3914 SDO pin */
    M_SDI_L;M_SDI_OUTPUT;M_SDI_L;

    /* 3914 SDO pin */
    M_SDO_L;M_SDO_OUTPUT;M_SDO_L;

    /* 3914 CS Open */
    M_CS_L;M_CS_OUTPUT;M_CS_L;

    /* 3914 Power Close */
    M_PWR_CT_H;M_PWR_CT_OUTPUT;M_PWR_CT_H;

    /* 3914 Clk Close */
    //M_PWM_CLK_L;M_PWM_CLK_OUTPUT;M_PWM_CLK_L;
    M_SCK_L;M_SCK_OUTPUT;M_SCK_L;

    M_DR_INT_INPUT;

    /* 3914 RST Close */
    M_RST_L;M_RST_OUTPUT;M_RST_L;
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_GPIO_PwrOnInit(void)
{
    PORT_DeInit();

    /* CF1/CF2 pin */
    CF2_H;CF2_OUTPUT;CF2_H;

    CF1_H;CF1_OUTPUT;CF1_H;

    /* ACT/REACT pin */
    //ACT_LED_H;ACT_LED_OUTPUT;ACT_LED_H;
    ACT_LED_L;ACT_LED_OUTPUT;ACT_LED_L;

    //REACT_LED_H;REACT_LED_OUTPUT;REACT_LED_H;

    m_HD_3914_PwrOffInit();

    /* Dataflash pin (no WP) */
    DF_SDI_INPUT;

    DF_CS_H;DF_CS_OUTPUT;DF_CS_H;

    DF_SDO_H;DF_SDO_OUTPUT;DF_SDO_H;

    DF_CLK_H;DF_CLK_OUTPUT;DF_CLK_H;

    /* IIC pin */
    TWI_SDA_H;TWI_SDA_OUTPUT;TWI_SDA_H;

    TWI_SCL_H;TWI_SCL_OUTPUT;TWI_SCL_H;

    /* Hard_jump pin */
    HARD_JUMP_DT_OUTPUT;HARD_JUMP_DT_L;//HARD_JUMP_DT_INPUT;

    /* YX1/2/3/4 pin */
    YX1_INPUT;

    YX2_INPUT;

    YX3_INPUT;

    YX4_INPUT;

    /* RTC_INT pin */
    RTC_INT_INPUT;
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_GPIO_PwrOffInit(void)
{

}


/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/

