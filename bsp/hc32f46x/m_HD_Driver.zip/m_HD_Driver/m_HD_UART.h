/*
*****************************************************************************
 Copyright (C)
 Module         : ����ģ��
 File Name      : m_HD_UART.h
 Description    :
 others         :
 Meter Type     ��
 ----------------------------------------------------------------------------
 Modification History:
 <No.> <version >  <time>        <author>     <contents>

*****************************************************************************
*/
#ifndef  __M_HD_UART_H__
#define  __M_HD_UART_H__

#include "m_MacroTypedef.h"

/*---------------------------------------------------------------------------*
 * TYPE AND CONSTANT                            *
 *---------------------------------------------------------------------------*/
#define COM_RX_TIMEOUT           50//50ms
#define RCV_BYTE_INTERVAL_TIME   8


typedef enum
{
    E_UART_CALI,
    E_UART_MAX,
}ENUM_UART_PORT;

typedef enum
{
    E_BAUD_300   = 0,
    E_BAUD_600   = 1,
    E_BAUD_1200  = 2,
    E_BAUD_2400  = 3,
    E_BAUD_4800  = 4,
    E_BAUD_9600  = 5,
    E_BAUD_19200 = 6,
    E_BAUD_38400 = 7,
    E_BAUD_MAX   = 8,
}ENUM_UART_BAUD;

typedef enum
{
    E_UART_7E1 = 0,
    E_UART_8N1 = 1,
    E_UART_8E1 = 2,
    E_UART_8O1 = 3,
}ENUM_UART_DATA;

/*---------------------------------------------------------------------------*
 * prototypes define                            *
 *---------------------------------------------------------------------------*/
#ifndef __M_HD_UART_C__
    #define __VAR_DEFINE  extern
#else
    #define __VAR_DEFINE
#endif


#undef __VAR_DEFINE


/*---------------------------------------------------------------------------*
 * external variables                           *
 *---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 * external routine prototypes                  *
 *---------------------------------------------------------------------------*/
extern U8   m_HD_UART_PwrOnInit(U8 ucChnl, U8 ucBaud, en_functional_state_t ucEnable);
extern U16  m_HD_UART_GetBuf(U8 ucChnl, U8 *pucBuf, U16 usMaxLen);
extern void m_HD_UART_TimeMechanism(U8 ucPeriod);
extern U8   m_HD_UART_SendBuf(U8 ucChnl, U8 *pucBuf, U16 usSendLen);

#endif

/*---------------------------------------------------------------------------*/
