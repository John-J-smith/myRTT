/*
*****************************************************************************
 Copyright (C)
 Module         : GPIOģ��
 File Name      : m_HD_GPIO.h
 Description    :
 others         :
 Meter Type     ��
 ----------------------------------------------------------------------------
 Modification History:
 <No.> <version >  <time>        <author>     <contents>

*****************************************************************************
*/
#ifndef  __M_HD_SPI_H__
#define  __M_HD_SPI_H__

#include "m_MacroTypedef.h"

/*---------------------------------------------------------------------------*
 * TYPE AND CONSTANT                            *
 *---------------------------------------------------------------------------*/
typedef enum
{
    E_HD_SPI_M3914,
    E_HD_SPI_SLAVE,
    E_HD_SPI_MAX,
}ENUM_HD_SPI;

/*---------------------------------------------------------------------------*
 * prototypes define                            *
 *---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 * external variables                           *
 *---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 * external routine prototypes                  *
 *---------------------------------------------------------------------------*/
extern U8 m_HD_SPI_SendBuf(U8 ucChnl, U8 *pucBuf, U8 ucLen);
extern U8 m_HD_SPI_GetBuf(U8 ucChnl, U8 *pucBuf, U8 ucLen);
extern U8 m_HD_SPI_Init(U8 ucChnl, en_functional_state_t ucEnable);
extern void m_HD_SPI_RAMInit(void);
extern void m_HD_DMA2_SPISt(U8 ucEnable);

#endif

/*---------------------------------------------------------------------------*/
