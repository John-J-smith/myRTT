/*
*****************************************************************************
 Copyright (C)
 Module         : SPI��ز���
 File Name      : m_HD_SPI.c
 Description    :
 others         :
 Meter Type     ��
 ----------------------------------------------------------------------------
 Modification History:
 <No.> <version >  <time>        <author>     <contents>

******************************************************************************
*/
#define   __M_HD_SPI_C__

/****************************************************************************/
/* ����ͷ�ļ� */

#ifndef   Debug_M_HD_SPI_err
#define   Debug_M_HD_SPI_err(n)
#endif

#include "m_HD_SPI.h"
#include "m_HD_GPIO.h"

/*****************************************************************************
 * prototypes define  *
 ****************************************************************************/
ST_COM_CTRL s_stSPICtrl;

/*****************************************************************************
        TYPE AND CONSTANT
*****************************************************************************/
/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
void m_HD_SPI_RAMInit(void)
{
    memset(&s_stSPICtrl, 0, sizeof(s_stSPICtrl));
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
U8 m_HD_SPI_Init(U8 ucChnl, en_functional_state_t ucEnable)
{
    U8 ucRtnValue;

    stc_spi_init_t stcSpiInit;
    stc_irq_regi_conf_t stcIrqRegiCfg;
    /* configuration structure initialization */
    MEM_ZERO_STRUCT(stcSpiInit);
    MEM_ZERO_STRUCT(stcIrqRegiCfg);

    ucRtnValue = true;
    if(ucRtnValue >= E_HD_SPI_MAX)
    {
        ucRtnValue = false;
    }
    else
    {
        switch(ucChnl)
        {
            case E_HD_SPI_M3914:
            {
                /* Configuration peripheral clock */
                PWC_Fcg1PeriphClockCmd(PWC_FCG1_PERIPH_SPI2, ucEnable);

                PORT_SetFunc(M_SCK_PORT, M_SCK_PIN, Func_Spi2_Sck, Disable);
                PORT_SetFunc(M_SDI_PORT, M_SDI_PIN, Func_Spi2_Mosi, Disable);
                PORT_SetFunc(M_SDO_PORT, M_SDO_PIN, Func_Spi2_Miso, Disable);

                stcSpiInit.enClkDiv = SpiClkDiv16;//42/32
                stcSpiInit.enFrameNumber = SpiFrameNumber1;
                stcSpiInit.enDataLength = SpiDataLengthBit8;
                stcSpiInit.enFirstBitPosition = SpiFirstBitPositionMSB;
                stcSpiInit.enSckPolarity = SpiSckIdelLevelHigh;
                stcSpiInit.enSckPhase = SpiSckOddChangeEvenSample;
                stcSpiInit.enReadBufferObject = SpiReadReceiverBuffer;
                stcSpiInit.enWorkMode = SpiWorkMode3Line;
                stcSpiInit.enTransMode = SpiTransFullDuplex;
                stcSpiInit.enCommAutoSuspendEn = Disable;
                stcSpiInit.enModeFaultErrorDetectEn = Disable;
                stcSpiInit.enParitySelfDetectEn = Disable;
                stcSpiInit.enParityEn = Disable;
                stcSpiInit.enParity = SpiParityEven;
                stcSpiInit.enMasterSlaveMode = SpiModeMaster;
                stcSpiInit.stcDelayConfig.enSsSetupDelayOption = SpiSsSetupDelayTypicalSck1;
                stcSpiInit.stcDelayConfig.enSsSetupDelayTime = SpiSsSetupDelaySck1;
                stcSpiInit.stcDelayConfig.enSsHoldDelayOption = SpiSsHoldDelayTypicalSck1;
                stcSpiInit.stcDelayConfig.enSsHoldDelayTime = SpiSsHoldDelaySck1;
                stcSpiInit.stcDelayConfig.enSsIntervalTimeOption = SpiSsIntervalTypicalSck1PlusPck2;
                stcSpiInit.stcDelayConfig.enSsIntervalTime = SpiSsIntervalSck1PlusPck2;

                SPI_Init(M4_SPI2, &stcSpiInit);

                SPI_Cmd(M4_SPI2, Enable);
            }break;
            case E_HD_SPI_SLAVE:
            {
                /* Configuration peripheral clock */
                PWC_Fcg1PeriphClockCmd(PWC_FCG1_PERIPH_SPI4, ucEnable);

                PORT_SetFunc(SLAVE_SPI_MOSI_PORT, SLAVE_SPI_MOSI_PIN, Func_Spi4_Mosi, Disable);
                PORT_SetFunc(SLAVE_SPI_MISO_PORT, SLAVE_SPI_MISO_PIN, Func_Spi4_Miso, Disable);
                PORT_SetFunc(SLAVE_SPI_CLK_PORT, SLAVE_SPI_CLK_PIN, Func_Spi4_Sck, Disable);
                m_EXIT_SPISlave_Init();
                //PORT_SetFunc(SLAVE_SPI_CS_PORT, SLAVE_SPI_CS_PIN, Func_Spi4_Nss0, Disable);

                stcSpiInit.enClkDiv = SpiClkDiv8;//42/32
                stcSpiInit.enFrameNumber = SpiFrameNumber1;
                stcSpiInit.enDataLength = SpiDataLengthBit8;
                stcSpiInit.enFirstBitPosition = SpiFirstBitPositionMSB;
                stcSpiInit.enSckPolarity = SpiSckIdleLevelLow;
                stcSpiInit.enSckPhase = SpiSckOddChangeEvenSample;
                stcSpiInit.enReadBufferObject = SpiReadReceiverBuffer;
                stcSpiInit.enWorkMode = SpiWorkMode3Line;
                stcSpiInit.enTransMode = SpiTransFullDuplex;
                stcSpiInit.enCommAutoSuspendEn = Disable;
                stcSpiInit.enModeFaultErrorDetectEn = Disable;
                stcSpiInit.enParitySelfDetectEn = Disable;
                stcSpiInit.enParityEn = Disable;
                stcSpiInit.enParity = SpiParityOdd;
                stcSpiInit.enMasterSlaveMode = SpiModeSlave;
                SPI_Init(M4_SPI4, &stcSpiInit);
            }break;
            default:
            {
                ucRtnValue = false;
            }break;
        }
    }

    return (ucRtnValue);
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
U8 m_HD_SPI_SendBuf(U8 ucChnl, U8 *pucBuf, U8 ucLen)
{
    U8 ucRtnValue;
    U8 ucCnt;
    M4_SPI_TypeDef *pstSPIHd;
    //U16 usSPIDelay = 0;

    pstSPIHd = NULL;
    ucRtnValue = true;
    if(ucChnl >= E_HD_SPI_MAX)
    {
        ucRtnValue = false;
    }
    else
    {
        for(ucCnt = 0; ucCnt < ucLen; ucCnt++)
        {
            if(ucChnl == E_HD_SPI_M3914)
            {
                pstSPIHd = M4_SPI2;
            }
            else
            {
                pstSPIHd = M4_SPI4;
            }
            while(SPI_GetFlag(pstSPIHd, SpiFlagSendBufferEmpty) == Reset);
            //m_MISC_Dlyus(500);
            SPI_SendData8(pstSPIHd, pucBuf[ucCnt]);
            while(SPI_GetFlag(pstSPIHd, SpiFlagReceiveBufferFull) == Reset);
            //m_MISC_Dlyus(500);
            SPI_ReceiveData8(pstSPIHd);
        }
    }

    return (ucRtnValue);
}

/********************************************************************************
Function name:
Description:
Input:
Output:
Return:
Nites:
.................................................................................
Modification History:
 <No.> <version>      <time>         <author>      <contents>
 2��
 1��
********************************************************************************/
U8 m_HD_SPI_GetBuf(U8 ucChnl, U8 *pucBuf, U8 ucLen)
{
    U8 ucRtnValue;
    U8 ucCnt;
    M4_SPI_TypeDef *pstSPIHd;

    pstSPIHd = NULL;
    ucRtnValue = true;
    if(ucChnl >= E_HD_SPI_MAX)
    {
        ucRtnValue = false;
    }
    else
    {
        for(ucCnt = 0; ucCnt < ucLen; ucCnt++)
        {
            if(ucChnl == E_HD_SPI_M3914)
            {
                pstSPIHd = M4_SPI2;
            }
            else
            {
                pstSPIHd = M4_SPI4;
            }
            while(SPI_GetFlag(pstSPIHd, SpiFlagSendBufferEmpty) == Reset);
            //m_MISC_Dlyms(1);
            SPI_SendData8(pstSPIHd, pucBuf[ucCnt]);
            while(SPI_GetFlag(pstSPIHd, SpiFlagReceiveBufferFull) == Reset);
            //m_MISC_Dlyms(1);
            pucBuf[ucCnt] = SPI_ReceiveData8(pstSPIHd);
        }
    }

    return (ucRtnValue);
}

