/*
*****************************************************************************
 Copyright (C)
 Module         : GPIOģ��
 File Name      : m_HD_GPIO.h
 Description    :
 others         :
 Meter Type     ��
 ----------------------------------------------------------------------------
 Modification History:
 <No.> <version >  <time>        <author>     <contents>

*****************************************************************************
*/
#ifndef  __M_HD_GPIO_H__
#define  __M_HD_GPIO_H__

#include "m_MacroTypedef.h"

/*---------------------------------------------------------------------------*
 * TYPE AND CONSTANT                            *
 *---------------------------------------------------------------------------*/
#define CF2_PORT               PortH
#define CF2_PIN                Pin02

#define CF1_PORT               PortC
#define CF1_PIN                Pin13

#define TTL_RXD_PORT           PortA
#define TTL_RXD_PIN            Pin00

#define TTL_TXD_PORT           PortA
#define TTL_TXD_PIN            Pin01

#define HARD_JUMP_DT_PORT      PortA
#define HARD_JUMP_DT_PIN       Pin02

#define M_PWR_CT_PORT          PortA
#define M_PWR_CT_PIN           Pin03

#define M_RST_PORT             PortA
#define M_RST_PIN              Pin04

#define M_SDI_PORT             PortA
#define M_SDI_PIN              Pin05

#define M_SDO_PORT             PortA
#define M_SDO_PIN              Pin06

#define M_SCK_PORT             PortA
#define M_SCK_PIN              Pin07

#define M_CS_PORT              PortB
#define M_CS_PIN               Pin00

#define M_PWM_CLK_PORT         PortB
#define M_PWM_CLK_PIN          Pin01

#define PWR_FAIL_DT_PORT       PortB
#define PWR_FAIL_DT_PIN        Pin02

#define M_DR_INT_PORT          PortB
#define M_DR_INT_PIN           Pin10

#define DF_MISO_PORT           PortB
#define DF_MISO_PIN            Pin12

#define DF_CS_PORT             PortB
#define DF_CS_PIN              Pin13

#define DF_MOSI_PORT           PortB
#define DF_MOSI_PIN            Pin14

#define DF_CLK_PORT            PortB
#define DF_CLK_PIN             Pin15

#define YX1_INPUT_PORT         PortA
#define YX1_INPUT_PIN          Pin08

#define YX2_INPUT_PORT         PortA
#define YX2_INPUT_PIN          Pin09

#define TWI_SDA_PORT           PortA
#define TWI_SDA_PIN            Pin10

#define RTC_INT_PORT           PortA
#define RTC_INT_PIN            Pin11

#define TWI_SCL_PORT           PortA
#define TWI_SCL_PIN            Pin12

#define YX3_INPUT_PORT         PortA
#define YX3_INPUT_PIN          Pin15

#define YX4_INPUT_PORT         PortB
#define YX4_INPUT_PIN          Pin03

#define SLAVE_SPI_MOSI_PORT    PortB
#define SLAVE_SPI_MOSI_PIN     Pin04

#define SLAVE_SPI_MISO_PORT    PortB
#define SLAVE_SPI_MISO_PIN     Pin05

#define REACT_LED_PORT         PortB
#define REACT_LED_PIN          Pin06

#define SLAVE_SPI_CS_PORT      PortB
#define SLAVE_SPI_CS_PIN       Pin07

#define ACT_LED_PORT           PortB
#define ACT_LED_PIN            Pin08

#define SLAVE_SPI_CLK_PORT     PortB
#define SLAVE_SPI_CLK_PIN      Pin09


/*---------------------------------------------------------------------------*
 * prototypes define                            *
 *---------------------------------------------------------------------------*/
#define CF2_OUTPUT             m_HD_GPIO_PinMode(CF2_PORT, CF2_PIN, Pin_Mode_Out, Enable)
#define CF2_H                  PORT_SetBits(CF2_PORT, CF2_PIN)

#define CF1_OUTPUT             m_HD_GPIO_PinMode(CF1_PORT, CF1_PIN, Pin_Mode_Out, Enable)
#define CF1_H                  PORT_SetBits(CF1_PORT, CF1_PIN)

#define HARD_JUMP_DT_INPUT     m_HD_GPIO_PinMode(HARD_JUMP_DT_PORT, HARD_JUMP_DT_PIN, Pin_Mode_In, Enable)
#define HARD_JUMP_DT_OUTPUT    m_HD_GPIO_PinMode(HARD_JUMP_DT_PORT, HARD_JUMP_DT_PIN, Pin_Mode_Out, Enable)
#define HARD_JUMP_DT_H         PORT_SetBits(HARD_JUMP_DT_PORT, HARD_JUMP_DT_PIN)
#define HARD_JUMP_DT_L         PORT_ResetBits(HARD_JUMP_DT_PORT, HARD_JUMP_DT_PIN)
#define HARD_JUMP_DT_TOGGLE    PORT_Toggle(HARD_JUMP_DT_PORT, HARD_JUMP_DT_PIN)

#define M_PWR_CT_OUTPUT        m_HD_GPIO_PinMode(M_PWR_CT_PORT, M_PWR_CT_PIN, Pin_Mode_Out, Enable)
#define M_PWR_CT_H             PORT_SetBits(M_PWR_CT_PORT, M_PWR_CT_PIN)
#define M_PWR_CT_L             PORT_ResetBits(M_PWR_CT_PORT, M_PWR_CT_PIN)

#define M_RST_OUTPUT           m_HD_GPIO_PinMode(M_RST_PORT, M_RST_PIN, Pin_Mode_Out, Enable)
#define M_RST_H                PORT_SetBits(M_RST_PORT, M_RST_PIN)
#define M_RST_L                PORT_ResetBits(M_RST_PORT, M_RST_PIN)

#define M_SDO_OUTPUT           m_HD_GPIO_PinMode(M_SDI_PORT, M_SDI_PIN, Pin_Mode_Out, Enable)
#define M_SDO_H                PORT_SetBits(M_SDI_PORT, M_SDI_PIN)
#define M_SDO_L                PORT_ResetBits(M_SDI_PORT, M_SDI_PIN)

#define M_SDI_INPUT            m_HD_GPIO_PinMode(M_SDO_PORT, M_SDO_PIN, Pin_Mode_In, Enable)
#define M_SDI_OUTPUT           m_HD_GPIO_PinMode(M_SDO_PORT, M_SDO_PIN, Pin_Mode_Out, Enable)
#define M_SDI_H                PORT_SetBits(M_SDO_PORT, M_SDO_PIN)
#define M_SDI_L                PORT_ResetBits(M_SDO_PORT, M_SDO_PIN)

#define M_SCK_INPUT            m_HD_GPIO_PinMode(M_SCK_PORT, M_SCK_PIN, Pin_Mode_In, Enable)
#define M_SCK_OUTPUT           m_HD_GPIO_PinMode(M_SCK_PORT, M_SCK_PIN, Pin_Mode_Out, Enable)
#define M_SCK_H                PORT_SetBits(M_SCK_PORT, M_SCK_PIN)
#define M_SCK_L                PORT_ResetBits(M_SCK_PORT, M_SCK_PIN)
#define M_CLK_TOGGLE           PORT_Toggle(M_SCK_PORT, M_SCK_PIN)

#define M_CS_OUTPUT            m_HD_GPIO_PinMode(M_CS_PORT, M_CS_PIN, Pin_Mode_Out, Enable)
#define M_CS_H                 M4_PORT->POSRB |= M_CS_PIN  //PORT_SetBits(M_CS_PORT, M_CS_PIN)
#define M_CS_L                 M4_PORT->PORRB |= M_CS_PIN  //PORT_ResetBits(M_CS_PORT, M_CS_PIN)

#define M_PWM_CLK_OUTPUT       m_HD_GPIO_PinMode(M_PWM_CLK_PORT, M_PWM_CLK_PIN, Pin_Mode_Out, Enable)
#define M_PWM_CLK_H            PORT_SetBits(M_PWM_CLK_PORT, M_PWM_CLK_PIN)
#define M_PWM_CLK_L            PORT_ResetBits(M_PWM_CLK_PORT, M_PWM_CLK_PIN)
#define M_PWM_CLK_TOGGLE       PORT_Toggle(M_PWM_CLK_PORT, M_PWM_CLK_PIN)

#define PWR_FAIL_DT_INPUT      m_HD_GPIO_PinMode(PWR_FAIL_DT_PORT, PWR_FAIL_DT_PIN, Pin_Mode_Ana, Enable)

#define M_DR_INT_INPUT         m_HD_GPIO_PinMode(M_DR_INT_PORT, M_DR_INT_PIN, Pin_Mode_In, Enable)

#define DF_SDI_INPUT           m_HD_GPIO_PinMode(DF_MISO_PORT, DF_MISO_PIN, Pin_Mode_In, Disable)
#define DF_SDI_PV              PORT_GetBit(DF_MISO_PORT, DF_MISO_PIN)
#define DF_SDI_OUTPUT          m_HD_GPIO_PinMode(DF_MISO_PORT, DF_MISO_PIN, Pin_Mode_Out, Enable)
#define DF_SDI_H               PORT_SetBits(DF_MISO_PORT, DF_MISO_PIN)
#define DF_SDI_L               PORT_ResetBits(DF_MISO_PORT, DF_MISO_PIN)

#define DF_CS_INPUT            m_HD_GPIO_PinMode(DF_CS_PORT, DF_CS_PIN, Pin_Mode_In, Enable)
#define DF_CS_OUTPUT           m_HD_GPIO_PinMode(DF_CS_PORT, DF_CS_PIN, Pin_Mode_Out, Enable)
#define DF_CS_H                PORT_SetBits(DF_CS_PORT, DF_CS_PIN)
#define DF_CS_L                PORT_ResetBits(DF_CS_PORT, DF_CS_PIN)

#define DF_SDO_INPUT           m_HD_GPIO_PinMode(DF_MOSI_PORT, DF_MOSI_PIN, Pin_Mode_In, Enable)
#define DF_SDO_OUTPUT          m_HD_GPIO_PinMode(DF_MOSI_PORT, DF_MOSI_PIN, Pin_Mode_Out, Enable)
#define DF_SDO_H               PORT_SetBits(DF_MOSI_PORT, DF_MOSI_PIN)
#define DF_SDO_L               PORT_ResetBits(DF_MOSI_PORT, DF_MOSI_PIN)

#define DF_CLK_INPUT           m_HD_GPIO_PinMode(DF_CLK_PORT, DF_CLK_PIN, Pin_Mode_In, Enable)
#define DF_CLK_OUTPUT          m_HD_GPIO_PinMode(DF_CLK_PORT, DF_CLK_PIN, Pin_Mode_Out, Enable)
#define DF_CLK_H               PORT_SetBits(DF_CLK_PORT, DF_CLK_PIN)
#define DF_CLK_L               PORT_ResetBits(DF_CLK_PORT, DF_CLK_PIN)

#define YX1_INPUT              m_HD_GPIO_PinMode(YX1_INPUT_PORT, YX1_INPUT_PIN, Pin_Mode_In, Enable)
#define YX1_GET                PORT_GetBit(YX1_INPUT_PORT, YX1_INPUT_PIN)

#define YX2_INPUT              m_HD_GPIO_PinMode(YX2_INPUT_PORT, YX2_INPUT_PIN, Pin_Mode_In, Enable)

#define TWI_SDA_OUTPUT         m_HD_GPIO_PinMode(TWI_SDA_PORT, TWI_SDA_PIN, Pin_Mode_Out, Enable)
#define TWI_SDA_H              PORT_SetBits(TWI_SDA_PORT, TWI_SDA_PIN)
#define TWI_SDA_L              PORT_ResetBits(TWI_SDA_PORT, TWI_SDA_PIN)

#define RTC_INT_INPUT          m_HD_GPIO_PinMode(RTC_INT_PORT, RTC_INT_PIN, Pin_Mode_In, Enable)

#define TWI_SCL_OUTPUT         m_HD_GPIO_PinMode(TWI_SCL_PORT, TWI_SCL_PIN, Pin_Mode_Out, Enable)
#define TWI_SCL_H              PORT_SetBits(TWI_SCL_PORT, TWI_SCL_PIN)
#define TWI_SCL_L              PORT_ResetBits(TWI_SCL_PORT, TWI_SCL_PIN)

#define YX3_INPUT              m_HD_GPIO_PinMode(YX3_INPUT_PORT, YX3_INPUT_PIN, Pin_Mode_In, Enable)

#define YX4_INPUT              m_HD_GPIO_PinMode(YX4_INPUT_PORT, YX4_INPUT_PIN, Pin_Mode_In, Enable)

#define REACT_LED_OUTPUT       m_HD_GPIO_PinMode(REACT_LED_PORT, REACT_LED_PIN, Pin_Mode_Out, Enable)
#define REACT_LED_H            PORT_SetBits(REACT_LED_PORT, REACT_LED_PIN)
#define REACT_LED_L            PORT_ResetBits(REACT_LED_PORT, REACT_LED_PIN)

#define ACT_LED_OUTPUT         m_HD_GPIO_PinMode(ACT_LED_PORT, ACT_LED_PIN, Pin_Mode_Out, Enable)
#define ACT_LED_H              PORT_SetBits(ACT_LED_PORT, ACT_LED_PIN)
#define ACT_LED_L              PORT_ResetBits(ACT_LED_PORT, ACT_LED_PIN)
#define ACT_LED_TOGGLE         PORT_Toggle(ACT_LED_PORT, ACT_LED_PIN)

/*---------------------------------------------------------------------------*
 * external variables                           *
 *---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 * external routine prototypes                  *
 *---------------------------------------------------------------------------*/
extern void m_HD_GPIO_Init(void);
extern void m_HD_GPIO_PwrOnInit(void);
extern void m_HD_GPIO_PinMode(en_port_t enPort, en_pin_t u16Pin, en_pin_mode_t pinMode, en_functional_state_t enNewState);
extern void m_HD_3914_PwrOnInit(void);
extern void m_EXIT_DR_Init(void);
extern void m_EXIT_DR_DeInit(void);
extern void m_EXIT_SPISlave_Init(void);

#endif

/*---------------------------------------------------------------------------*/
